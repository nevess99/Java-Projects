import static org.junit.Assert.assertEquals;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.swing.text.html.HTMLDocument.Iterator;

public class RemoveTester {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		/*
		 * OneArrayDictionary d = new OneArrayDictionary();
		 * 
		 * try { d.insertEntry("w1", "d1"); d.insertEntry("w2", "d2");
		 * d.insertEntry("w3", "d3"); d.insertEntry("w4", "d4"); d.insertEntry("w5",
		 * "d5");
		 * 
		 * 
		 * 
		 * 
		 * 
		 * } catch (WordAlreadyExistsInDictionaryException e) { // TODO Auto-generated
		 * catch block e.printStackTrace(); } catch (DictionaryFullException e) { //
		 * TODO Auto-generated catch block e.printStackTrace(); }
		 * 
		 * 
		 * try { d.removeWord("w2"); } catch (WordNotInDictionaryException e) { // TODO
		 * Auto-generated catch block e.printStackTrace(); }
		 * 
		 * 
		 * WordDefinitionPair wp = new WordDefinitionPair("w1","d1"); WordDefinitionPair
		 * wa = new WordDefinitionPair("w3","d3"); WordDefinitionPair wb = new
		 * WordDefinitionPair("w4","d4"); WordDefinitionPair wc = new
		 * WordDefinitionPair("w5","d5");
		 * 
		 * WordDefinitionPair[] wps = new WordDefinitionPair[] {wp,wa,wb,wc};
		 * 
		 * for(int i =0 ; i < 4;i++) {
		 * 
		 * System.out.println((String)(d.dict[i].getDefinition()) + " versus " +
		 * (String) wps[i].getDefinition());
		 * 
		 * System.out.println((String)(d.dict[i].getWord()) + " versus " + (String)
		 * wps[i].getWord()); }
		 * 
		 * 
		 * 
		 * 
		 * 
		 * TwoArrayDictionary a = new TwoArrayDictionary(); try { a.insertEntry("w1",
		 * "d1"); a.insertEntry("w2", "d2"); a.insertEntry("w3", "d3");
		 * a.insertEntry("w4", "d4"); a.insertEntry("w5", "d5");
		 * 
		 * a.removeWord("w3");
		 * 
		 * System.out.println((4 + "expected vs actual: " + a.size()));
		 * System.out.println((4 + "expected bs actual " + a.getWords().length));
		 * System.out.println( "" + "w1" + d.getWords()[0] + "\nw2" + d.getWords()[1] +
		 * "\nw4" + d.getWords()[2]+ "\nw5" + d.getWords()[3] + " " + 4 +
		 * " definition length " + d.getDefinitions().length + "\nd1" +
		 * d.getDefinitions()[0] + "\nd2" + d.getDefinitions()[1] // wrong entry +
		 * "\nd4"+ d.getDefinitions()[2] + "\nd5" + d.getDefinitions()[3] );
		 * 
		 * 
		 * System.out.println(Arrays.toString(d.getDefinitions()));
		 * System.out.println(Arrays.toString(d.getWords())); System.out.println( " " +
		 * 4 + " expect entries length vs actual " + d.getEntries().length);
		 * System.out.println( "\nw1" + d.getEntries()[0].getWord() + "\nd1"+
		 * d.getEntries()[0].getDefinition() + "\nw2" + d.getEntries()[1].getWord() +
		 * "\nd2" + d.getEntries()[1].getDefinition() + "\nw4" +
		 * d.getEntries()[2].getWord() + "\nd4" + d.getEntries()[2].getDefinition() +
		 * "\nw5" + d.getEntries()[3].getWord() + "\nd5" +
		 * d.getEntries()[3].getDefinition()); }
		 * 
		 * catch(Exception e) {
		 * 
		 * e.printStackTrace();
		 * 
		 * 
		 * }
		 */
		
		
		
		List<String> c= new ArrayList<>();
		Iterator iter = (Iterator) c.iterator();
		
		
		
		
		
		
		
	}

}
