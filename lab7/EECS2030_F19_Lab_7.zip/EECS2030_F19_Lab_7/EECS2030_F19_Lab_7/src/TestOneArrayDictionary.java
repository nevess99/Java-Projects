public class TestOneArrayDictionary extends TestDictionary {
	@Override
	protected Dictionary dict() {
		return new OneArrayDictionary();
	}
}
